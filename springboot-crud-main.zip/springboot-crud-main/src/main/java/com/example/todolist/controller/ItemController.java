package com.example.todolist.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.todolist.model.Item;
import com.example.todolist.service.ItemService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api")
public class ItemController {
	@Autowired
	ItemService itemService;
	
	@RequestMapping(value="/items", method=RequestMethod.POST)
	public Item createItem(@RequestBody Item item) {
	    return itemService.createItem(item);
	}

	@RequestMapping(value="/items", method=RequestMethod.GET)
	public List<Item> readItems() {
	    return itemService.getItems();
	}
	
	@RequestMapping(value="/items/{itemId}", method=RequestMethod.PUT)
	public Item updateItem(@PathVariable(value = "itemId") Long id, @RequestBody Item itemDetails) {
	    return itemService.updateItem(id, itemDetails);
	}
	
	@RequestMapping(value="/items/{itemId}", method=RequestMethod.DELETE)
	public void deleteItems(@PathVariable(value = "itemId") Long id) {
	    itemService.deleteItem(id);
	}
}



