package com.example.todolist.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.todolist.model.Item;
import com.example.todolist.repository.ItemsRepository;

@Service
public class ItemService {
	
	@Autowired
    ItemsRepository itemRepository;
	
	//CREATE
	public Item createItem(Item item) {
		item.setStatus(false);
	    return itemRepository.save(item);
	}
	
	//READ
	public List<Item> getItems() {
	    return itemRepository.findAll();
	}

	//UPDATE
	public Item updateItem(Long itemId, Item itemDetails) {
		Item item = itemRepository.findById(itemId).get();
		item.setContent(itemDetails.getContent());
		item.setStatus(itemDetails.getStatus());
		
		return itemRepository.save(item);				
	}

	//DELETE
	public void deleteItem(Long itemId) {
	    itemRepository.deleteById(itemId);
	}
}

